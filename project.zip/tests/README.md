# Framework tests

This directory contains tests for the framework.
These tests are used for testing the framework, not for testing your project.
Run these tests if you find a potential bug, to make sure that you did not break something in the framework.
